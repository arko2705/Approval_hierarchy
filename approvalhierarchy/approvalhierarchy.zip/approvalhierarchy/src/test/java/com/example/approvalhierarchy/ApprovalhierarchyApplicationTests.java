package com.example.approvalhierarchy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApprovalhierarchyApplicationTests {

	@Test
	void contextLoads() {
	}

}
